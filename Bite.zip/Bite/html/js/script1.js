// Function to add item to cart
function addToCart(button) {
    const product = button.parentNode;
    const name = product.querySelector("h3").textContent;
    const price = parseFloat(product.querySelector("p").textContent.replace("Price: $", ""));
    
    const cart = document.getElementById("cart-items");
    const cartItem = document.createElement("li");
    cartItem.textContent = `${name} - $${price}`;
    cart.appendChild(cartItem);

    // Update total price
    const totalPrice = document.getElementById("total-price");
    totalPrice.textContent = parseFloat(totalPrice.textContent) + price;
}
