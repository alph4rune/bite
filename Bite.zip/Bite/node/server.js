const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');

const app = express();
const port = 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/signupDB')
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch((err) => {
        console.error('Error connecting to MongoDB:', err);
    });

// Define a schema for users
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String
});

// Create a model based on the schema
const User = mongoose.model('User', userSchema);
app.set('view engine', 'ejs');

// Middleware for session management
app.use(session({
    secret: 'your-secret-key', // Change this to a random secret
    resave: false,
    saveUninitialized: true
}));

// Serve static files from the 'html' directory
app.use(express.static(path.join(__dirname, '..', 'html')));
// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.redirect('/signup.html');
});

// Serve signup.html when accessing http://localhost:3000/signup
app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'html', 'signup.html'));
});

app.get('/navbar', (req, res) => {
    // Retrieve the username from the session
    const username = req.session.user ? req.session.user.username : null;

    // Render the navbar template and pass the username
    res.render('navbar', { username: username });
});
// Handle signup form submission
app.post('/signup', async (req, res) => {
    try {
        const newUser = new User({
            username: req.body.username,
            email: req.body.email,
            password: req.body.password
        });
        await newUser.save();
        // Set user session upon successful signup
        req.session.user = { username: req.body.username };
        res.redirect('/success.html'); // Redirect to success.html page
    } catch (error) {
        res.status(500).send('Error saving user');
    }
});

// Handle login form submission
app.post('/login', async (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    try {
        const user = await User.findOne({ username: username, password: password });
        if (user) {
            // Set user session upon successful login
            req.session.user = { username: username };
            res.redirect('/home.html'); // Redirect to home.html page
        } else {
            res.status(401).send('Invalid username or password');
        }
    } catch (error) {
        res.status(500).send('Error occurred while logging in');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
